<template>
    <div>

    <h2>计数器：{{ conuterStore.count }}</h2>
    <h2>双倍计数器：{{ conuterStore.doubleCount }}</h2>
    <button @click="conuterStore.increment">增加</button>
    <button @click="conuterStore.decrement">增加</button>

    </div>
</template>

<script setup lang="ts">

import { useCounterStore } from '../stores/useCounter';

const conuterStore = useCounterStore();


</script>
