<template>
    <div>
    <div>
        <input type="text" v-model="recordId" placeholder="内容" />
        <input type="number" v-model="amount" placeholder="金额" />
        <select v-model="type">
            <option value="收入">收入</option>
            <option value="支出">支出</option>
        </select>

        <button @click="myAddRecord">添加</button>
    </div>

    <ul>
        <li v-for="(record, index) in myRecords" :key="record.id">
            <span class="record-text">
                {{ record.id }} - {{ record.type }} : {{ record.amount }}
            </span>
            <button @click="myRemoveRecord(record.id)">删除</button>
        </li>
    </ul>

    <h3>总计</h3>
    <p>总收入：{{ totalIncome }}</p>
    <p>总支出：{{ totalExpense }}</p>
    <p>余额：{{ last }}</p>
    </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { useAccountStore } from '../stores/useAccount';

const accountStore = useAccountStore();

const amount = ref(0);
const type = ref<'收入' | '支出'>('收入');
const recordId = ref(''); 

const myAddRecord = () => {
    if (amount.value > 0 && recordId.value) { 
        accountStore.addRecord(recordId.value, type.value, amount.value);
        amount.value = 0; 
        recordId.value = ''; 
    }
};

const myRemoveRecord = (id: string) => { 
    accountStore.removeRecord(id);
};

const myRecords = accountStore.records;
const totalIncome = accountStore.totalIncome;
const totalExpense = accountStore.totalExpense;
const last = accountStore.last;
</script>

<style scoped>
.record-text {
    margin-right: 10px;
}
</style>
