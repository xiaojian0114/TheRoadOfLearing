<template>
    <div>
      <h2>待办清单</h2>
      <input type="text" v-model="newTodoText" placeholder="请输入待办事项" />
      <button @click="myAddTodo">添加</button>
    </div>
    <ul>
      <li
        v-for="(todo, index) in myTodos"
        :key="todo.id"
        :class="{ completed: todo.completed }"
      >
      <span class="todo-text" @click="myToggleTodo(index)">
        {{ todo.text }}
      </span>

     
        <button @click="myRemoveTodo(index)">删除</button>
       
      </li>
    </ul>
  </template>
  
  <script setup lang="ts">
  import { useTodoStore } from '../stores/useTodo';
  import { ref } from 'vue';
  
  const todoStore = useTodoStore();
  
  const newTodoText = ref("");
  
  const myAddTodo = () => {
    if (newTodoText.value.trim()) {
      todoStore.addTodo(newTodoText.value);
      newTodoText.value = ""; // 清空输入框
    }
  };
  
  const myRemoveTodo = (index: number) => {
    todoStore.removeTodo(index);
  };
  
  const myToggleTodo = (index: number) => {
    todoStore.toggleTodo(index);
  };
  
  const myTodos = todoStore.todos;
  </script>
  
  <style scoped>
  .completed {
    text-decoration: line-through;
    text-decoration-thickness: 3px; /* 增加线条粗细 */
    text-decoration-color: red; /* 更改线条颜色 */
    text-decoration-style: solid; /* 线条样式为实线 */
    color: gray; 
  }

  .todo-text {
  cursor: pointer; /* 鼠标悬停时变为手指 */
}
  </style>
  