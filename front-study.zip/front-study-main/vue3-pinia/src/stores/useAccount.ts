import { defineStore } from "pinia";
import { ref, computed } from "vue";

interface Record {
    id: string; // 将 id 的类型改为 string
    type: '收入' | '支出';
    amount: number;
}

export const useAccountStore = defineStore('account', () => {
    const records = ref<Record[]>([]);

    // 添加记录
    const addRecord = (id: string, type: '收入' | '支出', amount: number): void => {
        const newRecord: Record = { 
            id,
            type,
            amount,
        };

        records.value.push(newRecord);
    };

    // 删除记录
    const removeRecord = (id: string): void => {
        records.value = records.value.filter(record => record.id !== id);
    };

    // 计算总收入
    const totalIncome = computed(() => {
        return records.value
            .filter(record => record.type === '收入')
            .reduce((sum, record) => sum + record.amount, 0);
    });

    // 计算总支出
    const totalExpense = computed(() => {
        return records.value
            .filter(record => record.type === '支出')
            .reduce((sum, record) => sum + record.amount, 0);
    });

    // 计算余额
    const last = computed(() => {
        return totalIncome.value - totalExpense.value;
    });

    return {
        records,
        addRecord,
        removeRecord,
        totalIncome,
        totalExpense,
        last,
    };
}, {
    persist: {
        key: 'my-account-records',
        storage: localStorage,
    },
});
