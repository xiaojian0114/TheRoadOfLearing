<template>
  <nav>
    <router-link to="/counter">计数器</router-link>
    <router-link to="/todo">代办清单</router-link>
    <router-link to="/account">记账帮手</router-link>
  </nav>

  <router-view />
</template>

<script setup lang="ts">


</script>

<style scoped>

a {
  margin: 10px;
  text-decoration: none;
  color: aqua;
  padding: 5px 10px;
}

.router-link-active {
  background-color: aqua;
  color: white;
  font-weight: bold;
}

</style>