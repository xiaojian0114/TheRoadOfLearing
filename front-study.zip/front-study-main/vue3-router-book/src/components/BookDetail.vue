<template>
  <div>
    <h2>{{ book.title }}</h2>
    <img :src="book.image" alt="书籍封面" />
    <p>{{ book.description }}</p>
    <button @click="addToCart">添加到购物车</button>


    
  </div>
</template>

<script lang="ts">
import { defineComponent, inject, Ref } from 'vue';
import { useRoute } from 'vue-router';

// 定义书籍的类型
interface Book {
  id: number;
  title: string;
  description: string;
  image: string; // 添加图片属性
}

export default defineComponent({
  setup() {
    const route = useRoute();
    const bookId = parseInt(route.params.id as string); // 将 id 转为数字
    const isAuthenticated = inject('isAuthenticated') as Ref<boolean>; // 获取全局登录状态
    const cart = inject('cart') as Ref<Book[]>; // 获取全局购物车并指定类型

    // 模拟书籍数据，包含图片链接
    const book: Book = {
      id: bookId,
      title: `人类简史${bookId}`,
      description: '十万年前，地球上至少有六种不同的人但今日，世界舞台为什么只剩下了我们自己？从只能啃食虎狼吃剩的残骨的猿人，到跃居食物链顶端的智人，从雪维洞穴壁上的原始人手印，到阿姆斯壮踩上月球的脚印，从认知革命、农业革命，到科学革命、生物科技革命，我们如何登上世界舞台成为万物之灵的？从公元前1776年的《汉摩拉比法典》，到1776年的美国独立宣言，从帝国主义、资本主义，到自由主义、消费主义，',
      image: 'https://my-bucket-wyj.oss-cn-shanghai.aliyuncs.com/images/%E4%BA%BA%E7%B1%BB%E7%AE%80%E5%8F%B2.jpg',
    };

    // 额外书籍数据
    const additionalBook: Book | null = {
      id: bookId + 1,
      title: `傲慢与偏见${bookId + 1}`,
      description: '这是傲慢与偏见',
      image: 'https://my-bucket-wyj.oss-cn-shanghai.aliyuncs.com/images/%E5%82%B2%E6%85%A2%E4%B8%8E%E5%81%8F%E8%A7%81.jpg',
    };

    const addToCart = () => {
      if (isAuthenticated.value) {
        cart.value.push(book); // 添加书籍到购物车
        alert(`${book.title} 已添加到购物车`); // 提示用户
      } else {
        alert('请先登录才能添加到购物车');
      }
    };

    return { book, addToCart };
  },
});
</script>

<style scoped>
.book-detail-container {
  max-width: 500px; /* 最大宽度 */
  margin: auto; /* 居中 */
  padding: 20px; /* 内边距 */
  background-color: #ffffff; /* 背景颜色 */
  border-radius: 8px; /* 圆角 */
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* 阴影效果 */
}

.book-title {
  text-align: center; /* 标题居中 */
  font-size: 24px; /* 字体大小 */
  margin-bottom: 15px; /* 底部间距 */
}

.book-image {
  width: 100%; /* 图片宽度为100% */
  height: auto; /* 自动高度 */
  border-radius: 5px; /* 圆角 */
  margin-bottom: 15px; /* 图片与描述之间的间距 */
}

.book-description {
  font-size: 16px; /* 字体大小 */
  margin-bottom: 20px; /* 底部间距 */
  line-height: 1.5; /* 行高 */
  color: #555; /* 字体颜色 */
}

.add-to-cart-button {
  width: 100%; /* 按钮宽度 */
  padding: 10px; /* 内边距 */
  background-color: #007bff; /* 按钮背景颜色 */
  color: white; /* 文字颜色 */
  border: none; /* 去掉边框 */
  border-radius: 5px; /* 圆角 */
  cursor: pointer; /* 鼠标指针变为手型 */
  transition: background-color 0.3s; /* 背景颜色过渡效果 */
}

.add-to-cart-button:hover {
  background-color: #0056b3; /* 悬停时的背景颜色 */
}
</style>
