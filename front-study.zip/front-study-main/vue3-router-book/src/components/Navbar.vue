<template>
    <nav>
      <ul>
        <li><router-link to="/">书籍列表</router-link></li>
        <li><router-link to="/cart">购物车</router-link></li>
        <li><router-link to="/login">登录</router-link></li>
      </ul>
    </nav>
  </template>
  
  <script lang="ts">
  import { defineComponent } from 'vue';
  
  export default defineComponent({
    name: 'Navbar',
  });
  </script>
  
  <style scoped>
nav {
  background-color: #343a40; /* 深色背景 */
  padding: 1rem;
}

ul {
  list-style-type: none;
  display: flex;
  justify-content: center; /* 居中对齐 */
  gap: 2rem;
}

li {
  display: inline;
}

a {
  color: #ffffff; /* 链接文字颜色 */
  text-decoration: none; /* 去掉下划线 */
  font-weight: bold; /* 加粗 */
  padding: 0.5rem 1rem; /* 内边距 */
  border-radius: 5px; /* 圆角 */
  transition: background-color 0.3s; /* 动画效果 */
}

a:hover {
  background-color: #495057; /* 悬停时的背景色 */
}
</style>