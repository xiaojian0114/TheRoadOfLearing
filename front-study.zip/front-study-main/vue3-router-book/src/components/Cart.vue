<template>
  <div>
    <h2>购物车</h2>
    <div v-if="cart.length === 0">购物车是空的。</div>
    <ul v-else>
      <li v-for="(item, index) in cart" :key="index">
        {{ item.title }}
        <button @click="removeFromCart(index)">删除</button>
      </li>
    </ul>
  </div>
</template>

<script lang="ts">
import { defineComponent, inject, Ref } from 'vue';

// 定义书籍的类型
interface Book {
  id: number;
  title: string;
  description: string;
}

export default defineComponent({
  setup() {
    const cart = inject('cart') as Ref<Book[]>; // 获取全局购物车并指定类型

    const removeFromCart = (index: number) => {
      cart.value.splice(index, 1); // 从购物车中删除对应的书籍
    };

    return { cart, removeFromCart };
  },
});
</script>

<style>
ul {
  list-style-type: none;
}
li {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}
button {
  background-color: red; /* 设置删除按钮颜色 */
  color: white;
  border: none;
  padding: 5px 10px;
  cursor: pointer;
}
button:hover {
  opacity: 0.8; /* 鼠标悬停效果 */
}
</style>
