<template>
  <div>
    <h2>书籍列表</h2>
    <ul>
      <li v-for="book in books" :key="book.id">
        <router-link :to="{ name: 'BookDetail', params: { id: book.id } }">
          {{ book.title }}
        </router-link>
      </li>
    </ul>
  </div>
</template>



<script lang="ts">
import { defineComponent } from 'vue';

export default defineComponent({
  setup() {
    const books = [
      { id: 1, title: '人类简史', image: 'https://my-bucket-wyj.oss-cn-shanghai.aliyuncs.com/images/%E4%BA%BA%E7%B1%BB%E7%AE%80%E5%8F%B2.jpg' }, // 替换为真实图片路径
      { id: 2, title: '傲慢与偏见', image: 'https://my-bucket-wyj.oss-cn-shanghai.aliyuncs.com/images/%E5%82%B2%E6%85%A2%E4%B8%8E%E5%81%8F%E8%A7%81.jpg' }, // 替换为真实图片路径
    ];
    return { books };
  },
});
</script>

<style scoped>
.book-list {
  list-style-type: none; /* 去掉列表标记 */
  padding: 0; /* 去掉内边距 */
}

.book-item {
  display: flex; /* 使用弹性盒布局 */
  align-items: center; /* 垂直居中对齐 */
  padding: 10px; /* 增加内边距 */
  border-bottom: 1px solid #eaeaea; /* 底部边框 */
  transition: background-color 0.3s; /* 增加背景色变化效果 */
}

.book-item:hover {
  background-color: #f5f5f5; /* 悬停时的背景色 */
}

.book-link {
  display: flex; /* 使链接内部元素也使用弹性盒布局 */
  align-items: center; /* 垂直居中对齐 */
  text-decoration: none; /* 去掉下划线 */
  color: #333; /* 文字颜色 */
}

.book-image {
  width: 50px; /* 图片宽度 */
  height: auto; /* 自动高度 */
  margin-right: 10px; /* 图片和标题之间的间距 */
  border-radius: 4px; /* 圆角 */
}
</style>
