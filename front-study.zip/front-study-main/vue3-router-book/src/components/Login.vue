<template>
  <div>
    <h2>登录</h2>
    <form @submit.prevent="login">
      <div>
        <label for="username">用户名:</label>
        <input type="text" id="username" v-model="username" required />
      </div>
      <div>
        <label for="password">密码:</label>
        <input type="password" id="password" v-model="password" required />
      </div>
      <button type="submit">登录</button>
    </form>
  </div>
</template>

<script lang="ts">
import { defineComponent, inject, ref, Ref } from 'vue'; 
import { useRouter } from 'vue-router';

export default defineComponent({
  setup() {
    const username = ref('');
    const password = ref('');
    const isAuthenticated = inject('isAuthenticated') as Ref<boolean>;
    const router = useRouter();

    const login = () => {
      // 模拟登录逻辑
      if (username.value && password.value) {
        isAuthenticated.value = true; // 登录成功，更新状态
        router.push('/'); // 登录后重定向到主页
      }
    };

    return { username, password, login };
  },
});
</script>

<style scoped>
.login-container {
  max-width: 400px; /* 最大宽度 */
  margin: auto; /* 居中 */
  padding: 20px; /* 内边距 */
  background-color: #ffffff; /* 背景颜色 */
  border-radius: 8px; /* 圆角 */
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* 阴影效果 */
}

h2 {
  text-align: center; /* 标题居中 */
  margin-bottom: 20px; /* 底部间距 */
}

.form-group {
  margin-bottom: 15px; /* 每个输入组的底部间距 */
}

label {
  display: block; /* 标签为块级元素 */
  margin-bottom: 5px; /* 标签底部间距 */
  font-weight: bold; /* 标签加粗 */
}

.form-input {
  width: 100%; /* 输入框宽度 */
  padding: 10px; /* 内边距 */
  border: 1px solid #ced4da; /* 边框 */
  border-radius: 5px; /* 圆角 */
  transition: border-color 0.3s; /* 边框颜色过渡效果 */
}

.form-input:focus {
  border-color: #007bff; /* 聚焦时的边框颜色 */
  outline: none; /* 去掉默认的轮廓 */
}

.login-button {
  width: 100%; /* 按钮宽度 */
  padding: 10px; /* 内边距 */
  background-color: #007bff; /* 按钮背景颜色 */
  color: white; /* 文字颜色 */
  border: none; /* 去掉边框 */
  border-radius: 5px; /* 圆角 */
  cursor: pointer; /* 鼠标指针变为手型 */
  transition: background-color 0.3s; /* 背景颜色过渡效果 */
}

.login-button:hover {
  background-color: #0056b3; /* 悬停时的背景颜色 */
}
</style>
