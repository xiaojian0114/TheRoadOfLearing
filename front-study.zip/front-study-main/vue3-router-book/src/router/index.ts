import { createRouter, createWebHistory } from 'vue-router';
import { inject, Ref } from 'vue'; // 添加这行
import BookList from '../components/BookList.vue';
import BookDetail from '../components/BookDetail.vue';
import Cart from '../components/Cart.vue';
import Login from '../components/Login.vue';

const routes = [
  { path: '/', component: BookList },
  { path: '/book/:id', name: 'BookDetail', component: BookDetail },
  { path: '/cart', component: Cart }, // 移除 requiresAuth
  { path: '/login', component: Login },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

// 导航守卫（可选）
router.beforeEach((to, from, next) => {
  const isAuthenticated = inject('isAuthenticated') as Ref<boolean>; // 确保 inject 和 Ref 被正确引入
  if (to.matched.some(record => record.meta.requiresAuth) && !isAuthenticated?.value) { // 可选链
    next({ path: '/login' });
  } else {
    next();
  }
});

export default router;
