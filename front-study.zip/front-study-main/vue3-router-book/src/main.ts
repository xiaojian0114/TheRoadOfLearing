import { createApp, ref } from 'vue';
import App from './App.vue';
import router from './router';
//import './style.css';

interface Book {
  id: number;
  title: string;
  description: string;
}

const isAuthenticated = ref(false); // 用户登录状态
const cart = ref<Book[]>([]); // 购物车状态

const app = createApp(App);
app.provide('isAuthenticated', isAuthenticated); // 提供全局登录状态
app.provide('cart', cart); // 提供全局购物车
app.use(router);
app.mount('#app');
