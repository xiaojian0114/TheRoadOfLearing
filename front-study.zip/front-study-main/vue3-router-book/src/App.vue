<template>
  <div id="app">
    <nav>
      <router-link to="/">书籍列表</router-link>
      <router-link to="/cart">购物车</router-link>
      <router-link to="/login">登录</router-link>
    </nav>
    <router-view />
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';

export default defineComponent({
  setup() {
    return {};
  },
});
</script>
<style scoped>
#app {
  font-family: 'Arial', sans-serif; /* 设置基础字体 */
  line-height: 1.6; /* 行高 */
  padding: 20px; /* 页面内边距 */
  background-color: #f4f4f4; /* 背景色 */
}

nav {
  background-color: #343a40; /* 深色背景 */
  padding: 1rem; /* 内边距 */
  border-radius: 8px; /* 圆角 */
  margin-bottom: 20px; /* 底部间距 */
}

ul {
  list-style-type: none; /* 去掉列表标记 */
  display: flex; /* 使用弹性盒布局 */
  justify-content: center; /* 居中对齐 */
  gap: 1.5rem; /* 项目之间的间距 */
}

li {
  display: inline;
}

a {
  color: #ffffff; /* 链接文字颜色 */
  text-decoration: none; /* 去掉下划线 */
  padding: 0.5rem 1rem; /* 内边距 */
  border-radius: 5px; /* 圆角 */
  transition: background-color 0.3s; /* 动画效果 */
}

a:hover {
  background-color: #495057; /* 悬停时的背景色 */
}
</style>