<template>
    <nav>
      <router-link to="/">首页</router-link>
      <router-link to="/articles">文章</router-link>
      <router-link to="/user">我的</router-link>
    </nav>
  
    <router-view v-slot="{ Component }">
      <transition name="fade" mode="out-in">
        <component :is="Component" />
      </transition>
    </router-view>
  </template>
  
  <script setup lang="ts">
  import { RouterLink } from 'vue-router';
  </script>
  
  <style scoped>
  a {
    margin: 10px;
    text-decoration: none;
    color: #1876c7;
    background-color: aquamarine;
    padding: 5px 10px;
  }
  
  .router-link-active {
    background-color: rgb(59, 8, 107);
    font-weight: bolder;
  }
  
  .fade-enter-active,
  .fade-leave-active {
    transition: opacity 1s;
  }
  
  .fade-enter, 
  .fade-leave-to /* .fade-leave-active in <2.1.8 */ {
    opacity: 0;
  }
  </style>
  