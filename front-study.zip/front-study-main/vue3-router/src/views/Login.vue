<template>
    <div>
        <h3>用户登录</h3>

        <!-- <input v-model="username" placeholder="用户名">
        <input type="password" v-model="password" placeholder="密码"> -->

        <button @click="handleLogin">登录</button>
        
        <!-- <p v-if="errorMessage" style="color: red;">{{ errorMessage }}</p> -->
    </div>
</template>

<script lang="ts" setup>
//import { ref } from "vue"
import { useRouter } from 'vue-router';


 const router = useRouter(); 

// const username = ref('');
// const password = ref('');
// const errorMessage = ref('');

// const u1 = 'wyj';
// const p1 = '123456';


const handleLogin = () => {

    localStorage.setItem("token","hello123");
    router.push("/user/profile");
   
    
    // if( username.value === u1 && password.value === p1){
        
    //     router.push("/user/profile");
    // }else{
    //     errorMessage.value = '用户信息错误';
    // }
};
</script>

<style scoped>
</style>
