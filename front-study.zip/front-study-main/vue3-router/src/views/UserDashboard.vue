<template>
    <div>

        <nav>
          <router-link to="/user/profile">用户信息</router-link>
          <router-link to="/user/setting">用户设置</router-link>
        </nav>

  <router-view></router-view>

    </div>
</template>
<style scoped>
nav {
    background-color: #f8f9fa;
    padding: 10px; 
    border-bottom: 1px solid #dee2e6;
}

nav a {
    margin: 0 15px; 
    text-decoration: none; 
    color: #007bff; 
    font-weight: 600; 
    transition: color 0.3s; 
}

nav a:hover {
    color: #0056b3; 
}

.router-view {
    padding: 20px; 
}
</style>

