<template>
    <div>
        <h2>{{ article?.title || '文章未找到' }}</h2>
        <p>{{ article?.content || '没有内容可显示' }}</p>
        
        
        <!-- <div style="height: 15px;">

            <p>这里是非常长长的页面内容</p>

        </div> -->

        <router-link :to="{ name: 'ArticleComments', params: { id: article.id } }">
            查看评论
        </router-link>
        <router-view></router-view>

    </div>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router';


const route = useRoute();
const articleId = route.params.id;

const articles = [
    {
        id: 1,
        title: "如何学习 Vue3",
        content: "学习"
    },
    {
        id: 2,
        title: "理解 Vue Router",
        content: "理解"
    },
];

const article = articles.find(a => a.id === Number(articleId));

</script>

<style scoped>


</style>
