<template>
    <div>
        <h4>评论</h4>
        <div v-for="comment in comments" :key="comment.id">
            <p>{{ comment.content }}</p>
        </div>
    </div>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router';
import { ref } from 'vue';

const route = useRoute();
const articleId = String(route.params.id); 


const commentsData: { [key: string]: { id: number; content: string }[] } = {
    1: [
        { id: 1, content: "这篇文章真不错！" },
        { id: 2, content: "我也很喜欢这篇文章。" },
    ],
    2: [
        { id: 3, content: "非常有用的内容，感谢分享！" },
        { id: 4, content: "期待更多这样的文章。" },
    ],
};

// 根据文章 ID 获取对应的评论
const comments = ref(commentsData[articleId] || []);

</script>

<style>
</style>
