<template>
    <div>
        <h3>用户信息设置</h3>
        <button @click="handleLogout">退出</button>

    </div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router';

const router = useRouter();

const handleLogout = () => {
    // 清除用户的登录状态
    localStorage.removeItem('token'); // 假设你是用 localStorage 来存储用户信息
    // 跳转到登录页面
    router.push('/login');
};
</script>

<style scoped>

</style>