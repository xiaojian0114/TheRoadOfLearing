<template>
    <div>

        <h2>文章列表</h2>

        <!-- <div style="height: 20px">
            <P>这里是非常长长的页面内容</P>
        </div> -->
        <ul>
            <li v-for="article in articles " :key="article.id">
 
                   <router-link :to="`/articles/${article.id}`">
                    {{ article.title }}
                   </router-link>
            </li>
        </ul>
    </div>
</template>

<script setup lang="ts">

const articles = [
    {
        id: 1,
        title: "如何学 Vue3",
    },

    {
        id: 2,
        title: "理解 Vue Router"
    },
];

</script>

<script lang="ts" >

export default {
    beforeRouteEnter(to,from,next) {
        console.log(to,from);
        console.log("进入该页面检查信息");
        next();


    }
}
</script>

<style scoped>

</style>