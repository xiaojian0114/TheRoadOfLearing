import { createRouter, createWebHistory } from "vue-router";


import Layout from "../views/Layout.vue";


const routes = [

    
    {
        path: '/',
        name: "Layout",
        component: Layout,
        redirect: "/home",
        children: [
            {
                path: "/home",
                name: "Home",
                component: () => import("../views/Home.vue"),
            },

            {
                path: '/articles',
                name: "ArticleList",
                component: () => import("../views/ArticleList.vue"),
            },

            {
                path: "/articles/:id",
                name: "ArticleDetail",
                component: () => import("../views/ArticleDetail.vue"),
                children: [
                    {
                        path: "comments",
                        name: "ArticleComments",
                        component: () => import("../views/ArticleComments.vue"),
                    },
                ],
            },

            {
                path: "/user",
                component: () => import("../views/UserDashboard.vue"),
                redirect: '/user/profile',
                children: [
                    {
                        path: "profile",
                        name: "UserProfile",
                        component: () => import("../views/UserProfile.vue"),
                    },
                    {
                        path: "setting",
                        name: "UserSetting",
                        component: () => import("../views/UserSetting.vue"), 
                    },
                ],
            },


        ]
        
    },


    {   
        path: '/login',
        name: "Login",
        component: () => import("../views/Login.vue"),
    },
  
   
   
];

const router = createRouter({
    history: createWebHistory(),
    routes,
    scrollBehavior(to, from, savedPosition) {
        if (savedPosition) {
            return savedPosition;
        } else {
            return { top: 0 };
        }
    },
});

// 合并守卫
router.beforeEach((to, from, next) => {
    //const isAuthenticated = !!localStorage.getItem('user'); // 检查是否有用户信息
    if (to.path.startsWith("/user") && !localStorage.getItem("token")) {
        alert("请先登录")
        next("/login"); // 如果没有登录，重定向到登录页面
    } else {
        next(); // 继续导航
    }
});

export default router;
