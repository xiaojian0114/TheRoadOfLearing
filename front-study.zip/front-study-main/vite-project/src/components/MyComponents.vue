<template>  
    <div>  
        
      <el-select v-model="selectedRole" placeholder="请选择你要评分的主体">  
        <el-option  
          v-for="role in roles"  
          :key="role.value"  
          :label="role.label"  
          :value="role.value">  
        </el-option>  
      </el-select>  
    
        
      <el-transfer  
        v-model="assignedUserIds"  
        :titles="['未选择对象', '已选择对象']"  
        :data="filteredUsers"  
        :render-content="renderFunc"  
        @change="handleTransferChange">  
      </el-transfer>  
    
      <p>请给出你的评分</p>

      <el-rate  
        
        v-if="assignedUserIds.length > 0"  
        v-model="currentRating"  
        :max="5"  
        @change="handleRatingChange">

      </el-rate>  
    </div>  
  </template>  
    
  <script>
    
  export default {  
    data() {  
      return {  
        selectedRole: '',  
        assignedUserIds: [],   
        roles: [  
          { value: 'admin', label: '主食' },  
          { value: 'user', label: '小吃' },  
            
        ],  
          
        allUsers: [  
          { id: 1, name: '蛋炒饭', role: 'admin' },  
          { id: 2, name: '面条', role: 'admin' },
          { id: 3, name: '馒头', role: 'admin' },
          { id: 4, name: '鸡块', role: 'user' },
          { id: 5, name: '汉堡', role: 'user' },  
          { id: 6, name: '可乐', role: 'user' },
            
        ],  
        currentRating: 0,  
      };  
    },  
    computed: {  
        
      filteredUsers() {  
        return this.allUsers  
          .filter(user => user.role === this.selectedRole)  
          .map(user => ({  
            key: user.id,   
            label: user.name,   
            disabled: false   
          }));  
      },  
    },  
    methods: {  
      handleTransferChange(newValues, direction, movedValues) {  
        // 处理用户移动的逻辑  
        console.log('Transfer changed', newValues, direction, movedValues);  
        // 注意：这里newValues和movedValues现在是ID数组，而不是用户对象数组  
      },  
      handleRatingChange(value) {  
        // 处理评分变化的逻辑  
        console.log('Rating changed to', value);  
        // 这里可以根据需要关联到特定的用户（例如，使用当前选中的用户ID）  
      },  
      // 自定义渲染函数，用于Transfer穿梭框的项  
      renderFunc(h, option) {  
        // option.label 是我们在filteredUsers中设置的用户名  
        return h('span', option.label);  
      },  
    },  
  };  
  </script>  
    
    
    <style scoped>  
    /* 基本的样式重置 */  
    * {  
      margin: 0;  
      padding: 0;  
      box-sizing: border-box;  
    }  
      
    /* 容器样式 */  
    div {  
      padding: 20px;  
      background-color: #f8f9fa; /* 浅灰色背景 */  
      border-radius: 8px;  
      margin: 20px;  
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);  
    }  
      
    /* 选择器样式 */  
    .el-select {  
      width: 100%; /* 使选择器占满父容器宽度 */  
      margin-bottom: 20px;  
    }  
      
    /* 穿梭框样式 */  
    .el-transfer {  
      margin-bottom: 20px;  
    }  
      
    /* 评分组件样式 */  
    .el-rate {  
      display: block; /* 如果需要 */  
      margin: 0 auto; /* 居中显示 */  
    }  
      
    /* 穿梭框中的列表项样式 */  
    .el-transfer-panel .el-list {  
      max-height: 300px; /* 限制穿梭框的高度 */  
      overflow-y: auto; /* 超出时显示滚动条 */  
    }  
      
    /* 穿梭框中的列表项悬停样式 */  
    .el-transfer-panel .el-list .el-transfer-item:hover {  
      background-color: #f2f2f2; /* 浅灰色背景悬停效果 */  
    }  
      
    /* 穿梭框标题样式 */  
    .el-transfer-panel__header {  
      background-color: #007bff; /* 标题背景颜色 */  
      color: #ffffff; /* 标题文字颜色 */  
      border-radius: 8px 8px 0 0; /* 顶部圆角 */  
    }  
      
    /* 穿梭框按钮样式 */  
    .el-transfer-button {  
      padding: 8px 16px; /* 按钮内边距 */  
      background-color: #007bff; /* 按钮背景颜色 */  
      color: #ffffff; /* 按钮文字颜色 */  
      border: none; /* 去除边框 */  
      border-radius: 4px; /* 按钮圆角 */  
      cursor: pointer; /* 鼠标悬停时显示指针 */  
    }  
      
    /* 穿梭框按钮悬停样式 */  
    .el-transfer-button:hover {  
      background-color: #0056b3; /* 深一点的蓝色背景悬停效果 */  
    }  
    </style>