<template>  
  <div>  
    <el-carousel :interval="4000" arrow="always">  
      <!-- Carousel items -->  
      <el-carousel-item v-for="(image, index) in images" :key="index">  
        <img :src="image" alt="Carousel Image" style="width: 100%; height: 100%;">  
      </el-carousel-item>  
    </el-carousel>  
  
    <div style="margin-top: 20px;">  
      <el-calendar>  
        <template #dateCell="{ date, data }">  
          <div :class="{'marked-date': isMarkedDate(date)}">  
            {{ data.date }}  
            <el-badge v-if="isMarkedDate(date)" class="item" :value="getBadgeValue(date)">  
              Marked  
            </el-badge>  
          </div>  
        </template>  
      </el-calendar>  
    </div>  
  </div>  
</template>  
  
<script>  
export default {  
  data() {  
    return {  
      images: [  
        '/path/to/your/image1.jpg',  
        '/path/to/your/image2.jpg',  
        '/path/to/your/image3.jpg'  
      ],  
      markedDates: [  
        '2023-04-01', // 示例标记日期  
        '2023-04-15' // 另一个示例标记日期  
      ]  
    };  
  },  
  methods: {  
    isMarkedDate(date) {  
      // 将日期转换为 'YYYY-MM-DD' 格式以便比较  
      const formattedDate = this.formatDate(date);  
      return this.markedDates.includes(formattedDate);  
    },  
    formatDate(date) {  
      // 格式化日期为 'YYYY-MM-DD'  
      const year = date.getFullYear();  
      const month = (date.getMonth() + 1).toString().padStart(2, '0');  
      const day = date.getDate().toString().padStart(2, '0');  
      return `${year}-${month}-${day}`;  
    },  
    getBadgeValue(date) {  
      // 这里可以根据需要返回不同的值或逻辑  
      // 例如，基于日期计算一些特定值  
      return 'Special';  
    }  
  }  
};  
</script>  
  
<style>  
.marked-date {  
  /* 可以添加一些CSS来突出显示标记的日期 */  
  font-weight: bold;  
  color: red;  
}  
.item {  
  margin-left: 5px;  
}  
</style>