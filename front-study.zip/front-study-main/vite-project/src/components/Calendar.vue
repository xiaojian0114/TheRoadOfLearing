<template>  
  <div>  
    <el-carousel :interval="4000" arrow="always" height="300px">  
      <el-carousel-item v-for="(image, index) in images" :key="index">  
        <div class="card-image" :style="{ backgroundImage: `url(${image})` }"></div>  
      </el-carousel-item>  
    </el-carousel>  
  
    <div style="margin-top: 20px;">  
      <el-date-picker  
        v-model="value"  
        type="date"  
        placeholder="选择日期"  
        :picker-options="pickerOptions"  
        @change="handleChange"  
      ></el-date-picker>  
    </div>  
  </div>  
</template>  
  
<script>  
// 导入图片路径，Webpack 会处理这些路径并返回它们的 URL  
import Oc from '@/assets/Oc.png';  
import Win from '@/assets/Win.png';  
  
export default {  
  data() {  
    return {  
      images: [Oc, Win],  
      value: '',  
      markedDates: [  
        new Date(2024, 9, 25), // 注意：月份是从 0 开始的，所以 9 代表 10 月  
        new Date(2024, 9, 27)  
      ]  
    };  
  },  
  computed: {  
    pickerOptions() {  
      // ... 保持不变  
    }  
  },  
  methods: {  
    handleChange(value) {  
      console.log("Selected date:", value);  
    }  
  }  
};  
</script>  
  
<style scoped>  
.card-image {  
  width: 100%;  
  height: 100%;  
  background-size: cover;  
  background-position: center;  
  border-radius: 8px; /* 添加圆角以模拟卡片效果 */  
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1); /* 添加阴影以增强卡片效果 */  
}  
  
.image-cards {  
  display: flex;  
  flex-wrap: wrap;  
  margin: -10px; /* 用于内部元素的外边距负值调整，以消除间距 */  
}  
  
.image-card {  
  flex: 0 0 calc(50% - 20px); /* 假设每行展示两个卡片，每个卡片占 50% 减去间距 */  
  margin: 10px;  
  box-shadow: 0 2px 12px rgba(0,0,0,0.1); /* 添加一些阴影效果 */  
  overflow: hidden; /* 防止图片溢出 */  
}  
  
.image-card img {  
  width: 100%;  
  height: auto;  
  display: block; /* 去除图片下方的间隙 */  
  transition: transform 0.3s ease; /* 添加一些过渡效果 */  
}  
  
.image-card:hover img {  
  transform: scale(1.05); /* 鼠标悬停时放大图片 */  
}  
  

</style>