<template>
  <div>


    
    
    
    <BadgePage />
    <SelectDropdown />
    <SliderDemo />
    <Switch />




    <LoginForm />
    <ProductList />
    <RateForm />
    <Tranfers />
    <TransferComponent />
    <MyComponents />
    <Carousel />

    <BugugeComponent />
    
    <Calendar />
    
   


  </div>
</template>

<script setup lang="ts">

//import Calendar from './components/Calendar.vue';


//import EmailFormParent from './components/EmailFormParent.vue';
//import LoginForm from './components/LoginForm.vue';
//import ProductList from './components/ProductList.vue';
//import BadgePage from './components/BadgePage.vue';
//import SelectDropdown from './components/SelectDropdown.vue';
//import Switch from './components/Switch.vue';
//import RateForm from './components/RateForm.vue';
//import Tranfers from './components/Tranfers.vue';
//import Carousel from './components/BugageComponent.vue.vue';
import MyComponents from './components/MyComponents.vue';
//import TransferComponent from './components/TransferComponent.vue';
//import SliderDemo from './components/SliderDemo.vue';
//import RateForm from './components/RateForm.vue';
//import BugageComponent from './components/BugageComponent.vue';
















</script>