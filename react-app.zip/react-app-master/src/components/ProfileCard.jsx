import React from "react";
import "../styles/profileCard.css";

export default function ProfileCard() {
  return (
    <div className="profile-card">
      <div className="avatar-container">
        <img
          className="avatar"
          src="https://via.placeholder.com/150"
          alt="Profile"
        />
      </div>
      <h1>Your Name</h1>
      <h2>Your Title</h2>
      <div className="bio">
        <p>Your bio goes here. Describe yourself in a few sentences.</p>
      </div>
      <div className="skills">
        <h3>Skills</h3>
        <ul>
          <li>React</li>
          <li>JavaScript</li>
          <li>CSS</li>
        </ul>
      </div>
      <div className="contact">
        <h3>Contact</h3>
        <div className="social-links">
          <a href="#">Twitter</a>
          <a href="#">GitHub</a>
          <a href="#">LinkedIn</a>
        </div>
      </div>
    </div>
  );
}
